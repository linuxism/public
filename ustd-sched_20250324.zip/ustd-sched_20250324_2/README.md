### DDL

```mysql
CREATE TABLE IF NOT EXISTS `schedule` (
`id` varchar(255) NOT NULL,
`name` varchar(255) NOT NULL,
`cron` varchar(50) NOT NULL,
`command` varchar(255) DEFAULT NULL,
`enabled` bit(1) DEFAULT NULL,
`type` varchar(255) DEFAULT NULL,
`created` datetime(6) NOT NULL DEFAULT current_timestamp(6),
`updated` datetime(6) DEFAULT NULL,
PRIMARY KEY (`id`),
UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `job` (
`id` varchar(255) NOT NULL,
`command` varchar(255) NULL,
`elapsed` bigint(20) NULL,
`finished` bigint(20) NULL,
`name` varchar(255) NULL,
`pid` bigint(20) NULL,
`result` varchar(15) NULL,
`schedule_id` varchar(255) NOT NULL,
`started` bigint(20) NULL,
`type` varchar(255) NOT NULL,
`created` datetime(6) NOT NULL DEFAULT current_timestamp(6),
PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
```
