package io.ustd.sched.common;

/**
 * 공통 상수를 정의합니다.
 */
public class Constants {

    public static final String UTC = "UTC";
}
