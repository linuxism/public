package io.ustd.sched.service;

import io.ustd.sched.common.JobType;
import io.ustd.sched.common.Result;
import io.ustd.sched.domain.Job;
import io.ustd.sched.domain.entity.JobEntity;
import io.ustd.sched.repository.JobRepository;
import io.ustd.sched.util.Utils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.util.StopWatch;

import java.util.Arrays;
import java.util.List;

@RequiredArgsConstructor
@Service
@Slf4j
public class JobServiceImpl implements JobService {

    private final ModelMapper modelMapper = ModelMapper.INSTANCE;
    private final JobRepository jobRepository;

    @Async
    @Override
    public void execute(Job job) {
        if (job == null || job.getType() == null) {
            log.error("Job information is invalid.");
            return;
        }

        // Job ID 생성 및 시작 시간 설정
        job.setId(Utils.generateTsid());
        job.setStarted(Utils.getEpochMillis());

        // Job 유형별 실행
        switch (job.getType()) {
            case SHELL -> executeShell(job);
            default -> log.warn("Job type is not supported. type: {}", job.getType());
        }
    }

    @Override
    public void executeShell(Job job) {
        log.info("Job started. id: {}, name: {}, type: {}, command: {}", job.getId(), job.getName(), job.getType(), job.getCommand());

        // Process 생성
        List<String> args = Arrays.asList(job.getCommand().split(" "));
        ProcessBuilder pb = new ProcessBuilder(args);
        pb.redirectOutput(ProcessBuilder.Redirect.DISCARD);

        try {
            StopWatch sw = new StopWatch();
            sw.start(JobType.SHELL.name());

            // Process 시작 및 대기
            Process process = pb.start();
            int exitCode = process.waitFor();

            // Process 종료 처리
            sw.stop();
            job.setPid(process.pid());
            job.setFinished(Utils.getEpochMillis());
            job.setElapsed(job.getFinished() - job.getStarted());

            // Process 실행 결과 확인
            if (exitCode == 0) {
                job.setResult(Result.SUCCESS);
                log.info("Job success. id: {}, name: {}, pid: {}, {}", job.getId(), job.getName(), job.getPid(), sw);
            } else {
                job.setResult(Result.FAILURE);
                log.warn("Job failed. id: {}, name: {}, pid: {}, exitCode: {}, {}", job.getId(), job.getName(), job.getPid(), exitCode, sw);
            }

            // Job process 정보 저장
            saveJob(job);
        } catch (Exception e) {
            log.error("Job failed. id: {}, name: {}", job.getId(), job.getName(), e);
        }
    }

    @Override
    public void saveJob(Job job) {
        JobEntity jobEntity = modelMapper.toJobEntity(job);
        jobEntity.setNew(true);
        jobRepository.save(jobEntity).subscribe();
    }
}
