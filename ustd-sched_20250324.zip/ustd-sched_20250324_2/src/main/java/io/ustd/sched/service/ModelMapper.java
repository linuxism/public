package io.ustd.sched.service;

import io.ustd.sched.domain.Job;
import io.ustd.sched.domain.entity.JobEntity;
import io.ustd.sched.domain.entity.ScheduleEntity;
import io.ustd.sched.domain.Schedule;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.ReportingPolicy;
import org.mapstruct.factory.Mappers;

@Mapper(unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface ModelMapper {

    ModelMapper INSTANCE = Mappers.getMapper(ModelMapper.class);

    @Mapping(source = "schedule.id", target = "scheduleId")
    Job toJob(Schedule schedule);

    Job toJob(JobEntity jobEntity);

    JobEntity toJobEntity(Job job);

    Schedule toSchedule(ScheduleEntity scheduleEntity);

    ScheduleEntity toScheduleEntity(Schedule schedule);
}
