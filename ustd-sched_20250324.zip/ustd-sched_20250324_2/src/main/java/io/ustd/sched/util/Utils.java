package io.ustd.sched.util;

import io.hypersistence.tsid.TSID;
import org.springframework.util.StopWatch;

import java.time.ZoneId;
import java.time.ZonedDateTime;

/**
 * Utility 기능들을 제공합니다.
 */
public class Utils {

    /**
     * TSID를 생성합니다.
     * @return TSID
     */
    public static String generateTsid() {
        return TSID.Factory.getTsid1024().toString();
    }

    /**
     * 현재 시간에 대한 epoch milliseconds 값을 확인합니다.
     * @return epoch milliseconds
     */
    public static long getEpochMillis() {
        return ZonedDateTime.now(ZoneId.of("UTC")).toInstant().toEpochMilli();
    }

    public static StopWatch stopStartSw(StopWatch stopWatch, String task) {
        if (stopWatch != null && stopWatch.isRunning()) {
            stopWatch.stop();
            stopWatch.start(task);
        }
        return stopWatch;
    }

    public static StopWatch stopSw(StopWatch stopWatch) {
        if (stopWatch != null && stopWatch.isRunning()) {
            stopWatch.stop();
        }
        return stopWatch;
    }
}
