package io.ustd.sched.domain;

import io.ustd.sched.common.JobType;
import lombok.*;

@AllArgsConstructor
@Builder
@Getter
@NoArgsConstructor
@Setter
public class Schedule {

    private String id;

    private String command;

    private String cron;

    private boolean enabled;

    private String name;

    private JobType type;
}
