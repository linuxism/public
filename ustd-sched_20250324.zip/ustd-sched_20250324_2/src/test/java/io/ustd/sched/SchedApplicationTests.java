package io.ustd.sched;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SchedApplicationTests {

    @Test
    void contextLoads() {
    }

}
