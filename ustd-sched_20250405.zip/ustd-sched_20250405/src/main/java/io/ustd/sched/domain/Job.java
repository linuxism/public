package io.ustd.sched.domain;

import io.ustd.sched.common.JobType;
import io.ustd.sched.common.Result;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

/**
 * Job 정보를 설정합니다.
 */
@Builder
@Getter
@Setter
public class Job {

    private String id;

    private String command;

    private String dir;

    private long elapsed;

    private long finished;

    private boolean inheritIo;

    private String message;

    private String name;

    private Long pid;

    private Result result;

    private String scheduleId;

    private long started;

    private Long timeout;

    private JobType type;
}
