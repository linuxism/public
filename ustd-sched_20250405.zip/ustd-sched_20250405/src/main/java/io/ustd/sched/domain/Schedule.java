package io.ustd.sched.domain;

import io.ustd.sched.common.JobType;
import lombok.*;

@AllArgsConstructor
@Builder
@Getter
@NoArgsConstructor
@Setter
public class Schedule {

    private String id;

    private String command;

    private String cron;

    private String dir;

    private boolean enabled;

    private boolean inheritIo;

    private String name;

    private Long timeout;

    private JobType type;
}
