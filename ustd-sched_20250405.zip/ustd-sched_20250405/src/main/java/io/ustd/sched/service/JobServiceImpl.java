package io.ustd.sched.service;

import io.ustd.sched.common.JobType;
import io.ustd.sched.common.Result;
import io.ustd.sched.domain.Job;
import io.ustd.sched.domain.entity.JobEntity;
import io.ustd.sched.repository.JobRepository;
import io.ustd.sched.util.Utils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.util.StopWatch;
import org.springframework.util.StringUtils;

import java.io.File;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.TimeUnit;

@RequiredArgsConstructor
@Service
@Slf4j
public class JobServiceImpl implements JobService {

    private final ModelMapper modelMapper;
    private final JobRepository jobRepository;

    @Async
    @Override
    public void execute(Job job) {
        if (job == null || job.getType() == null) {
            log.error("Job information is invalid.");
            return;
        }

        // Job ID 생성 및 시작 시간 설정
        job.setId(Utils.generateTsid());
        job.setStarted(Utils.getEpochMillis());

        // Job 유형별 실행
        switch (job.getType()) {
            case SHELL -> executeShell(job);
            default -> log.warn("Job type is not supported. type: {}", job.getType());
        }
    }

    @Override
    public void executeShell(Job job) {
        log.info("Job started. id: {}, name: {}, type: {}, command: {}", job.getId(), job.getName(), job.getType(), job.getCommand());

        // Process 생성
        List<String> args = Arrays.asList(job.getCommand().split(" "));
        ProcessBuilder pb = new ProcessBuilder(args);

        // Working directory 설정
        if (StringUtils.hasText(job.getDir())) {
            pb.directory(new File(job.getDir()));
        }

        // Process 입/출력 처리
        if (job.isInheritIo()) {
            pb.inheritIO();
        } else {
            pb.redirectOutput(ProcessBuilder.Redirect.DISCARD);
        }

        try {
            StopWatch sw = new StopWatch();
            sw.start(JobType.SHELL.name());

            // Process 시작 및 대기
            Process process = pb.start();
            int exitCode = 0;
            if (job.getTimeout() != null) {
                // Timeout 설정 된 경우 시간 내 미완료 시 프로세스를 강제 종료시킴
                if (!process.waitFor(job.getTimeout(), TimeUnit.SECONDS)) {
                    exitCode = 99;
                    process.destroyForcibly();
                }
            } else {
                exitCode = process.waitFor();
            }

            // Process 종료 처리
            sw.stop();
            job.setPid(process.pid());
            job.setFinished(Utils.getEpochMillis());
            job.setElapsed(job.getFinished() - job.getStarted());

            // Process 실행 결과 확인
            if (exitCode == 0) {
                job.setResult(Result.SUCCESS);
                log.info("Job success. id: {}, name: {}, pid: {}, {}", job.getId(), job.getName(), job.getPid(), sw);
            } else {
                job.setResult(Result.FAILURE);
                job.setMessage("exitCode: " + exitCode);
                log.warn("Job failed. id: {}, name: {}, pid: {}, exitCode: {}, {}", job.getId(), job.getName(), job.getPid(), exitCode, sw);
            }

            // Job process 정보 저장
            saveJob(job);
        } catch (Exception e) {
            // Job 실패 처리
            job.setFinished(Utils.getEpochMillis());
            job.setElapsed(job.getFinished() - job.getStarted());
            job.setResult(Result.FAILURE);
            job.setMessage(e.getMessage());
            saveJob(job);
            log.error("Job failed. id: {}, name: {}", job.getId(), job.getName(), e);
        }
    }

    @Override
    public void saveJob(Job job) {
        JobEntity jobEntity = modelMapper.toJobEntity(job);
        jobEntity.setNew(true);
        jobRepository.save(jobEntity).subscribe();
    }
}
