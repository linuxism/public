package io.ustd.sched.service;

import io.ustd.sched.domain.Schedule;
import reactor.core.publisher.Flux;

public interface ScheduleService {

    /**
     * Schedule 정보 목록을 조회합니다.
     * @return schedule 정보 목록
     */
    Flux<Schedule> getSchedules();

    /**
     * Cron expression 파싱 후 분 단위 기준에서 현재 시간과 매칭되는지 확인합니다.
     * @param cronExpression cron expression
     * @return 현재 시간 매칭 여부
     */
    boolean isMatchCron(String cronExpression);

    /**
     * 매분 마다 실행 작업을 확인합니다.
     */
    void schedule();
}
