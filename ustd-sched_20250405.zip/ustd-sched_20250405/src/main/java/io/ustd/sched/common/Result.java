package io.ustd.sched.common;

/**
 * 결과
 */
public enum Result {
    FAILURE,
    SUCCESS
}
