package io.ustd.sched.service;

import io.ustd.sched.domain.Job;
import io.ustd.sched.domain.entity.JobEntity;
import io.ustd.sched.domain.entity.ScheduleEntity;
import io.ustd.sched.domain.Schedule;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.ReportingPolicy;

@Mapper(componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface ModelMapper {

    @Mapping(source = "schedule.id", target = "scheduleId")
    Job toJob(Schedule schedule);

    Job toJob(JobEntity jobEntity);

    JobEntity toJobEntity(Job job);

    Schedule toSchedule(ScheduleEntity scheduleEntity);

    ScheduleEntity toScheduleEntity(Schedule schedule);
}
