package io.ustd.sched.service;

import io.ustd.sched.domain.Job;

/**
 * Job 정보 설정 및 실행 기능들을 구현합니다.
 */
public interface JobService {

    /**
     * Job을 실행합니다.
     * @param job job 정보
     */
    void execute(Job job);

    /**
     * Shell script job을 실행합니다.
     * @param job job 정보
     */
    void executeShell(Job job);

    /**
     * Job 정보를 저장합니다.
     * @param job job 정보
     */
    void saveJob(Job job);
}
