plugins {
    java
    id("org.springframework.boot") version "3.4.3"
    id("io.spring.dependency-management") version "1.1.7"
}

group = "io.ustd"
version = "0.0.1-SNAPSHOT"

java {
    toolchain {
        languageVersion = JavaLanguageVersion.of(21)
    }
}

configurations {
    compileOnly {
        extendsFrom(configurations.annotationProcessor.get())
    }
}

repositories {
    mavenCentral()
}

ext {
    extra["mapStructVersion"] = "1.6.3"
}

dependencies {
    annotationProcessor("org.projectlombok:lombok")
    annotationProcessor("org.mapstruct:mapstruct-processor:${property("mapStructVersion")}")
    annotationProcessor("org.springframework.boot:spring-boot-configuration-processor")
    compileOnly("org.projectlombok:lombok")

    implementation("com.cronutils:cron-utils:9.2.1")
    implementation("com.github.ben-manes.caffeine:caffeine")
    implementation("io.asyncer:r2dbc-mysql:1.4.0")
    implementation("io.hypersistence:hypersistence-utils-hibernate-63:3.9.3")
    implementation("org.mapstruct:mapstruct:${property("mapStructVersion")}")
    implementation("org.springframework.boot:spring-boot-starter-data-r2dbc")
    implementation("org.springframework.boot:spring-boot-starter-webflux")

    testImplementation("org.springframework.boot:spring-boot-starter-test")
    testImplementation("io.projectreactor:reactor-test")
    testRuntimeOnly("org.junit.platform:junit-platform-launcher")
}

tasks.withType<Test> {
    //useJUnitPlatform()
    exclude("*")
}
