rootProject.name = "ustd-sched"
