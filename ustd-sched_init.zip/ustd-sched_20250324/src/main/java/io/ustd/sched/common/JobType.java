package io.ustd.sched.common;

/**
 * Schedule job 실행 유형
 */
public enum JobType {

    /**
     * Shell script
     */
    SHELL
}
