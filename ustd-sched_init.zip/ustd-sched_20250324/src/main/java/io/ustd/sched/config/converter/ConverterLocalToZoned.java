package io.ustd.sched.config.converter;

import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import org.springframework.core.convert.converter.Converter;
import org.springframework.data.convert.ReadingConverter;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;

@ReadingConverter
@RequiredArgsConstructor
public class ConverterLocalToZoned implements Converter<LocalDateTime, ZonedDateTime> {

    @Override
    public ZonedDateTime convert(@NonNull LocalDateTime source) {
        return ZonedDateTime.of(source, ZoneId.systemDefault());
    }
}
