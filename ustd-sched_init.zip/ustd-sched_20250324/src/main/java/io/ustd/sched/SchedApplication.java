package io.ustd.sched;

import io.ustd.sched.common.Constants;
import jakarta.annotation.PostConstruct;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.util.TimeZone;

@SpringBootApplication
public class SchedApplication {

    public static void main(String[] args) {
        SpringApplication.run(SchedApplication.class, args);
    }

    @PostConstruct
    public void init() {
        TimeZone.setDefault(TimeZone.getTimeZone(Constants.UTC));
    }
}
