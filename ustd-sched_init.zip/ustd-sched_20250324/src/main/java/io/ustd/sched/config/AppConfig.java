package io.ustd.sched.config;

import com.cronutils.model.CronType;
import com.cronutils.model.definition.CronDefinition;
import com.cronutils.model.definition.CronDefinitionBuilder;
import com.cronutils.parser.CronParser;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Application 공통 기능을 설정합니다.
 */
@Configuration
public class AppConfig {

    /**
     * Spring cron expression를 지원하는 cron parser를 설정합니다.
     * @return cron parser
     */
    @Bean
    public CronParser cronParser() {
        CronDefinition cronDefinition = CronDefinitionBuilder.instanceDefinitionFor(CronType.SPRING);
        return new CronParser(cronDefinition);
    }
}
