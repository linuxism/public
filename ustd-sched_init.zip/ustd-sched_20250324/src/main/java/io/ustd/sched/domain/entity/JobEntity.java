package io.ustd.sched.domain.entity;

import io.ustd.sched.common.JobType;
import lombok.*;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Transient;
import org.springframework.data.domain.Persistable;
import org.springframework.data.relational.core.mapping.Table;

import java.time.ZonedDateTime;

@AllArgsConstructor
@Builder
@Getter
@NoArgsConstructor
@Setter
@Table(name = "job")
public class JobEntity implements Persistable<String> {

    @Id
    private String id;

    /**
     * Job command
     */
    private String command;

    /**
     * Job 실행 시간
     */
    private long elapsed;

    /**
     * Job 완료 시간
     */
    private long finished;

    /**
     * Job 이름
     */
    private String name;

    /**
     * Job process ID
     */
    private Long pid;

    /**
     * Schedule ID
     */
    private String scheduleId;

    /**
     * Job 시작 시간
     */
    private long started;

    /**
     * Job 유형
     */
    private String type;

    private ZonedDateTime created;

    @Transient
    @Builder.Default
    private boolean isNew = false;

    @Override
    public boolean isNew() {
        return isNew;
    }
}
