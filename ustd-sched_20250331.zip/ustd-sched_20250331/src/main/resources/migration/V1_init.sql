CREATE TABLE IF NOT EXISTS `schedule` (
`id` varchar(255) NOT NULL,
`name` varchar(255) NOT NULL,
`type` varchar(255) DEFAULT NULL,
`cron` varchar(50) NOT NULL,
`command` varchar(255) DEFAULT NULL,
`dir` varchar(255) DEFAULT NULL,
`timeout` int(11) DEFAULT NULL,
`enabled` bit(1) DEFAULT NULL,
`created` datetime(6) NOT NULL DEFAULT current_timestamp(6),
`updated` datetime(6) DEFAULT NULL,
PRIMARY KEY (`id`),
UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `job` (
`id` varchar(255) NOT NULL,
`schedule_id` varchar(255) NOT NULL,
`name` varchar(255) DEFAULT NULL,
`type` varchar(255) NOT NULL,
`command` varchar(255) DEFAULT NULL,
`started` bigint(20) DEFAULT NULL,
`finished` bigint(20) DEFAULT NULL,
`elapsed` bigint(20) DEFAULT NULL,
`result` varchar(15) DEFAULT NULL,
`pid` bigint(20) DEFAULT NULL,
`message` varchar(255) DEFAULT NULL,
`created` datetime(6) NOT NULL DEFAULT current_timestamp(6),
PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
