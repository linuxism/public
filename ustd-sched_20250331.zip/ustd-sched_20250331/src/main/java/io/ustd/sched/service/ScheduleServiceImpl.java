package io.ustd.sched.service;

import com.cronutils.model.Cron;
import com.cronutils.model.time.ExecutionTime;
import com.cronutils.parser.CronParser;
import com.github.benmanes.caffeine.cache.AsyncLoadingCache;
import com.github.benmanes.caffeine.cache.Caffeine;
import io.ustd.sched.domain.entity.ScheduleEntity;
import io.ustd.sched.domain.Schedule;
import io.ustd.sched.repository.ScheduleRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.scheduling.support.CronExpression;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.time.LocalTime;
import java.time.ZonedDateTime;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.TimeUnit;

@RequiredArgsConstructor
@Service
@Slf4j
public class ScheduleServiceImpl implements ScheduleService {

    private final CronParser cronParser;
    private final JobService jobService;
    private final ModelMapper modelMapper;
    private final ScheduleRepository scheduleRepository;

    /**
     * Schedule 정보 목록 로컬 cache
     */
    private final AsyncLoadingCache<String, List<Schedule>> scheduleCache = Caffeine.newBuilder()
            .expireAfterWrite(1, TimeUnit.HOURS)
            .buildAsync((key, executor) -> {
                log.debug("Schedule loading for {}", key);
                return getSchedules().collectList().toFuture();
            });

    @Override
    public Flux<Schedule> getSchedules() {
        Flux<ScheduleEntity> schedulesFlux = scheduleRepository.findAllByEnabledOrderByIdDesc(true);
        return schedulesFlux.map(modelMapper::toSchedule);
    }

    @Override
    public boolean isMatchCron(String cronExpression) {
        if (!StringUtils.hasText(cronExpression) || !CronExpression.isValidExpression(cronExpression)) {
            log.error("Cron expression is invalid. cronExpression: {}", cronExpression);
            return false;
        }

        try {
            // Cron expression parsing
            ZonedDateTime now = ZonedDateTime.now();
            Cron cron = cronParser.parse(cronExpression);

            // 마지막 스케줄 시간 확인
            ExecutionTime executionTime = ExecutionTime.forCron(cron);
            Optional<ZonedDateTime> lastExecutionOpt = executionTime.lastExecution(now);
            if (lastExecutionOpt.isEmpty()) {
                return false;
            }

            // 현재 시간과 비교하여 분 단위 까지 매칭 여부 확인
            ZonedDateTime lastExecutionTime = lastExecutionOpt.get();
            LocalTime nowLocalTime = LocalTime.of(now.getHour(), now.getMinute());
            return lastExecutionTime.toLocalDate().equals(now.toLocalDate()) && lastExecutionTime.toLocalTime().equals(nowLocalTime);
        } catch (Exception e) {
            log.error("Cron expression parsing failed. cronExpression: {}", cronExpression, e);
            return false;
        }
    }

    @Override
    @Scheduled(initialDelay = 1000, fixedDelay = 60_000)
    public void schedule() {
        log.info("Scheduler started.");

        // Schedule 정보 목록 조회
        Mono<List<Schedule>> schedulesMono = Mono.fromCompletionStage(scheduleCache.get("schedules"));

        // Schedule job 실행
        schedulesMono.subscribe(schedules -> schedules.stream()
                .filter(schedule -> isMatchCron(schedule.getCron()))
                .forEach(schedule -> jobService.execute(modelMapper.toJob(schedule)))
        );
    }
}
