package io.ustd.sched.repository;

import io.ustd.sched.domain.entity.JobEntity;
import org.springframework.data.r2dbc.repository.R2dbcRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface JobRepository extends R2dbcRepository<JobEntity, String> {
}
