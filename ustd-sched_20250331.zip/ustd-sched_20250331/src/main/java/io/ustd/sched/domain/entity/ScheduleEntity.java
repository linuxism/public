package io.ustd.sched.domain.entity;

import lombok.*;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Transient;
import org.springframework.data.domain.Persistable;
import org.springframework.data.relational.core.mapping.Table;

import java.time.ZonedDateTime;

@AllArgsConstructor
@Builder
@Getter
@NoArgsConstructor
@Setter
@Table(name = "schedule")
public class ScheduleEntity implements Persistable<String> {

    @Id
    private String id;

    /**
     * Job command
     */
    private String command;

    /**
     * Cron expression
     */
    private String cron;

    /**
     * 활성화 여부
     */
    private boolean enabled;

    /**
     * Job 실행 working directory
     */
    private String dir;

    /**
     * 스케줄 이름
     */
    private String name;

    /**
     * Job 실행 timeout(seconds)
     */
    private Long timeout;

    /**
     * Job 실행 유형
     */
    private String type;

    private ZonedDateTime created;

    private ZonedDateTime updated;

    @Transient
    @Builder.Default
    private boolean isNew = false;

    @Override
    public boolean isNew() {
        return isNew;
    }
}
