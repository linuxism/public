package io.ustd.sched.repository.callback;

import io.ustd.sched.domain.entity.JobEntity;
import lombok.NonNull;
import org.reactivestreams.Publisher;
import org.springframework.data.r2dbc.mapping.event.BeforeConvertCallback;
import org.springframework.data.relational.core.sql.SqlIdentifier;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.time.ZonedDateTime;

@Component
public class JobBeforeConvertCallback implements BeforeConvertCallback<JobEntity> {

    @NonNull
    @Override
    public Publisher<JobEntity> onBeforeConvert(JobEntity entity, @NonNull SqlIdentifier table) {
        entity.setCreated(ZonedDateTime.now());
        return Mono.just(entity);
    }
}
