package io.ustd.sched.repository.callback;

import io.ustd.sched.domain.entity.ScheduleEntity;
import io.ustd.sched.util.Utils;
import lombok.NonNull;
import org.reactivestreams.Publisher;
import org.springframework.data.r2dbc.mapping.event.BeforeConvertCallback;
import org.springframework.data.relational.core.sql.SqlIdentifier;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import reactor.core.publisher.Mono;

import java.time.ZonedDateTime;

@Component
public class ScheduleBeforeConvertCallback implements BeforeConvertCallback<ScheduleEntity> {

    @NonNull
    @Override
    public Publisher<ScheduleEntity> onBeforeConvert(ScheduleEntity entity, @NonNull SqlIdentifier table) {
        ZonedDateTime now = ZonedDateTime.now();
        if (!StringUtils.hasText(entity.getId())) {
            entity.setId(Utils.generateTsid());
        }
        entity.setCreated(now);
        entity.setUpdated(now);
        return Mono.just(entity);
    }
}
