package io.ustd.sched.repository;

import io.ustd.sched.domain.entity.ScheduleEntity;
import org.springframework.data.r2dbc.repository.R2dbcRepository;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Flux;

@Repository
public interface ScheduleRepository extends R2dbcRepository<ScheduleEntity, String> {

    Flux<ScheduleEntity> findAllByEnabledOrderByIdDesc(boolean enabled);
}
